-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: happyhousedb
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board` (
  `memberid` varchar(20) DEFAULT NULL,
  `boardid` int NOT NULL AUTO_INCREMENT,
  `boardtitle` varchar(50) DEFAULT NULL,
  `boardcontent` varchar(2048) DEFAULT NULL,
  `regtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`boardid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
INSERT INTO `board` VALUES ('집요정',1,'주택청약 질문드립니다ㅠㅠ','안녕하세요 주택청약을 2021년 9월4일날 가입을했습니다\n1회차 2만원만 내고 입금을 한번도 하지 않고있는데\n다음달부터 달마다 5만원씩 넣을려고 계획중입니다\n근데 궁금한게 가입하고 돈을 안넣은지 너무 오래되서 다음달부터 매달 넣어도 난중에 손해보는거 아닌가싶어서 탈퇴후 재가입할지 생각을하고있는데 어떻게 해야할까요??','2022-05-25 16:15:07'),('저축왕',2,'질문	 신축아파트 월세','신축 나홀로 아파트 월세 문의해요\n보존등기는 난 1년미만 신축아파트에요\n최우선변제금 2천만원인 경기도 지역이고요\n융자는 꽉찼어요\n그런데 보증금은 2천만은 안하고\n오로지 3천만에 월세로 한다는데\n최우선변제금보다 천만원 많은데\n맘편히 계약해도 되나요?\n아니면 무조건 2천만원 보증금으로만 해야하나요?\n행여나 경매시\n천만원 못받으면 명도까지 계속 살다가 집 다때려부셔놓고 갱판 친다하면 낙찰자가 이사비랑 천만원 소중히 내어줄까요??\n아니면 발악해바야 무조건 천만원 까이나요??','2022-05-25 16:16:24'),('부동산손님',3,'화곡6동 강서구청근처의 빌라 전세 시세를 알고 싶습니다','화곡6동 강서구청근처의 정확한 빌라 전세 시세를 알고 싶습니다.\n\n지어진지 4년내, 전용면적 : 15~20평, 층은 상관없습니다.\n\n검색해봐도...화곡6동 부근만 모아서 보기가 매우 힘드네요..','2022-05-25 16:21:43'),('강남에산다',4,'안양시 평촌지역 14~15평형 아파트 전세가격','안양시 평촌지역에 14~15평형 아파트 전세를 알아보고 있습니다.\n\n현재 외국에 있는몸이라 직접돌아다닐수도 전화로 자세하게 물어볼수도 없는 상황입니다.\n\n올3월초에는 귀국하면 바로 입주해야되는데 답답한마음에 여기에 글을 올려봅니다.\n\n부동산에서 찾아보면 평촌부흥동에 은하수한양14평,관악타운성원15평이 1억~1억500만원대에도 여러군데가 나와있는데요.\n\n공인중개사에 메일로 문의를 했더니 요즘시세가 많이올라서1억1천 만원선이라네요.ㅡㅡ;','2022-05-25 16:25:54'),('집요정',5,'서판교 주변환경과 시세 공유해주세요','서판교로 이사를 고민하고 있습니다.\n아무래도 서판교가 자연친화적인 곳이라 동판교보다 쾌적한 느낌이 들어서요..\n여러가지 궁금한 사항이 있는데요..\n\n1. 강북, 강남으로 가는 대중교통과 주변편의시설을 알려주세요\n2. 판교원7단지 30평대를 검토하고 있는데, 아직 네이버에는 매물정보가 없네요..ㅠㅠ\n30평대 전세, 매매 시세 공유 좀 해주세요~\n3. 7단지 관리비도 궁금합니다. 이번겨울처럼 추웠을 때 보통 얼마 나오나요?\n서판교 거주하시는 분들 정보 공유 부탁드려요','2022-05-25 16:37:22');
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-26 10:44:33
