-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: happyhousedb
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notice`
--

DROP TABLE IF EXISTS `notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notice` (
  `noticeNo` int NOT NULL AUTO_INCREMENT,
  `memberId` varchar(16) DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `content` varchar(2000) DEFAULT NULL,
  `regTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`noticeNo`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice`
--

LOCK TABLES `notice` WRITE;
/*!40000 ALTER TABLE `notice` DISABLE KEYS */;
INSERT INTO `notice` VALUES (1,'admin','주상복합 단지정보 표시 안내','안녕하세요.\n해피 하우스입니다.\n\n해피 하우스에서는 용적률, 근생 시설 여부, 용도지역에 따라 주상복합에 해당하는 아파트의 경우 \'주상복합\'임을 표시하고 있습니다.\n\n앞으로는 매물정보를 제공함에 있어 건축법상의 용도를 표시하는 것이 보다 적합할 것으로 판단되어 건축물대장상의 용도인 \'아파트\'로 표시를 변경할 예정입니다. \n단, 사용자 편의를 위해 아파트 명칭 뒤에 주상복합임을 부기하여 표시할 예정입니다. \n\n*적용 대상: 해피 하우스, 검색 서비스 내 단지 종류를 주상복합에서 \'아파트\'로 변경\n*적용 일정: 2022년 3월 10일\n\n좋은 서비스를 제공하기 위해 늘 노력하는 해피 하우스이 되겠습니다.\n감사합니다.','2022-05-25 16:10:15'),(2,'admin','부동산 서비스 이용제한과 관련한 안내','안녕하세요?\n보다 안전하고 편리한 부동산 서비스 이용을 위해 안내드리니 이용에 참조를 부탁드립니다.\n \n네이버 이용약관에 따라 네이버 서비스를 이용하는 사용자는 네이버의 사전 허락 없이 자동화된 수단(예: 매크로 프로그램, 로봇(봇), 스파이더, 스크래퍼 등)을 이용하여 네이버 서비스에 게재된 회원의 아이디(ID), 게시물 등을 수집하거나, 네이버 검색 서비스에서 특정 질의어로 검색하거나 혹은 그 검색결과에서 특정 검색결과를 선택(이른바 ‘클릭’)하는 등 이용자(사람)의 실제 이용을 전제로 하는 네이버 서비스의 제공 취지에 부합하지 않는 방식으로 네이버 서비스를 이용하거나, 이와 같은 네이버 서비스에 대한 어뷰징(남용) 행위를 막기 위한 네이버의 기술적 조치를 무력화하려는 일체의 행위(예: IP를 지속적으로 바꿔가며 접속하는 행위, Captcha를 외부 솔루션 등을 통해 우회하거나 무력화 하는 행위 등)를 시도해서는 안 됩니다.\n \n또한 네이버의 동의 없이 자동화된 수단에 의해 네이버 서비스 상에 광고가 게재되는 영역 또는 그 밖의 영역에 부호, 문자, 음성, 음향, 그림, 사진, 동영상, 링크 등으로 구성된 각종 콘텐츠 자체 또는 파일을 삽입해서는 안 됩니다. 또한, 네이버 서비스 또는 이에 포함된 소프트웨어를 복사, 수정할 수 없으며, 이를 판매, 양도, 대여 또는 담보로 제공하거나 타인에게 그 이용을 허락해서는 안 됩니다. 그 밖에 바이러스나 기타 악성 코드를 업로드하거나 해피하우스서비스의 원활한 운영을 방해할 목적으로 서비스 기능을 비정상적으로 이용하는 행위 역시 금지됩니다\n \n해피하우스에서는 위와 같이 약관상 금지되는 서비스 어뷰징(남용) 행위를 막기 위해 기술적 조치를 시행하고 있으며, 사용자의 부정 접근이 의심(IP를 지속적으로 바꿔가며 접속하는 행위, 솔루션 등을 통해 우회하거나 무력화하는 행위, 클라우드 서비스를 통한 접근 등)되는 경우 서비스에 제한이 있을 수 있습니다. \n \n\n만약 정상적인 접근을 시도하였는데도 불구하고 서비스 이용에 제한이 있는 경우에는 해피하우스 고객센터로 문의해주시면 확인 후 회신을 드릴 수 있도록 하겠습니다.\n\n감사합니다.','2022-05-25 16:11:22'),(3,'admin','대출 서비스 종료 안내','안녕하세요.\n\n\n네이버부동산 매물정보 내 제공되고 있는 대출 서비스가 2019년 8월 31일자로 종료될 예정입니다.\n\n그동안 서비스를 이용해주신 고객 여러분께 감사 드립니다. \n\n \n\n더 좋은 서비스로 찾아뵙겠습니다. \n\n \n\n \n\n감사합니다. ','2022-05-25 16:11:40'),(4,'admin','매물 상세 페이지 개편 안내','안녕하세요. 네이버 부동산입니다.\n\n네이버 부동산 매물 정보 페이지가 더욱 보기 편리하게 개선되었습니다.\n\n \n\n \n\n01. 중요한 정보는 한눈에 쏙~\n\n가격, 면적, 층, 시세 등의 핵심 정보를 모아 페이지 최상단에 배치했습니다. 중요한 정보! 한눈에 확인하세요. ','2022-05-25 16:12:06'),(5,'admin','해피 하우스 서비스 장애가 복구되었습니다','안녕하세요, 해피 하우스입니다.\n\n2022년 5월 25일 해피 하우스 서비스에 장애가 발생했습니다.\n\n- 장애 서비스 : 해피 하우스 홈 접속 불안\n\n- 장애 시간 : 5월 25일 15시 3분 부터 15시 28분 까지\n\n긴급 복구작업을 통해 오류를 수정했고, 현재 정상적으로 서비스를 이용하실 수 있습니다.\n \n\n이용에 불편을 드린 점 고개 숙여 사과 드리며, 더욱 안정적인 서비스로 보답할 수 있도록 최선을 다하겠습니다. 고객 여러분의 양해 부탁 드립니다.','2022-05-25 16:13:36'),(6,'admin','공지사항입니다.','공지사항내용입니다.','2022-05-25 18:58:18');
/*!40000 ALTER TABLE `notice` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-26 10:44:32
