-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: happyhousedb
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `boardcomment`
--

DROP TABLE IF EXISTS `boardcomment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `boardcomment` (
  `memberid` varchar(20) DEFAULT NULL,
  `boardid` int DEFAULT NULL,
  `commentid` int NOT NULL AUTO_INCREMENT,
  `commentcontent` varchar(2048) DEFAULT NULL,
  `regtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`commentid`),
  KEY `qnacomment_ibfk_1` (`boardid`),
  CONSTRAINT `qnacomment_ibfk_1` FOREIGN KEY (`boardid`) REFERENCES `board` (`boardid`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `boardcomment`
--

LOCK TABLES `boardcomment` WRITE;
/*!40000 ALTER TABLE `boardcomment` DISABLE KEYS */;
INSERT INTO `boardcomment` VALUES ('저축왕',1,1,'탈퇴하시는건 안된다고 생각합니다...','2022-05-25 16:17:06'),('부동산손님',1,2,'탈퇴하시고 재가입하셔도 될거같아요!','2022-05-25 16:21:21'),('집구하자',3,3,'강서구청 인근에 2005년 이후 지은 빌라들의 전세가는 지상층으로 하여 전용면적 15평~20평은평형에 따라 11,000만원에서 14,000만원정도 합니다. 그러나 요즘은 물건이 없어서 임대인은 이보다도 높게 내놓는 상황이나 학기초가 지나면서 임차 수요가 다소 줄어드는 듯 싶습니다.','2022-05-25 16:22:38'),('강남에산다',3,4,'전용15평이면, 방2 거실 나오는구조부터 시작되서 보통 방3 거실 화장실1 전용20평이면, 방3 거실 화2개 까지 나오네요 방2 거실나오는구조가 연식오래된것은 9천에도 매물 나오는것은 있고요,  연식 오래 된것 아니면, 1억이상이네요^^','2022-05-25 16:25:21'),('admin',5,5,'','2022-05-25 19:31:00');
/*!40000 ALTER TABLE `boardcomment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-26 10:44:22
