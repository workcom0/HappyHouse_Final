-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: happyhousedb
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `memberId` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `memberPw` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tel` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `isAdmin` int DEFAULT '0',
  PRIMARY KEY (`memberId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES ('11','$2a$10$XkDV4gpfsoqzg4cKF1NV3O2HX69kwWsqfNekCffzsgY8v7Xxegmuu','11','11@11','113',0),('111','$2a$10$T0kI5rn9eYjTcSJcsc26a.rC3h.zIH.SfpkgHggoncaARlA6t0jKi','111','111@111','111',0),('123','$2a$10$BErgmPcDM0ctnauogSC.9.4bg4sYJul4T2Q.5AHR2mVmKK6G8oEVa','123','123@123','123',0),('22','$2a$10$0gcFHPIBnOzAibJbindhJuWROkl/qUK1SmRJMFX4XD2q5AfX5utfW','221','22@22','22',0),('321','$2a$10$MPpEr438cUjCQVrTrGl72egKouFugawig6TuqhWvV1hwZeJwpAJh2','321','321@321','321',0),('33','$2a$10$K4KzxLcVBOArM3vK9/i/Ae5ujTEg.BbSImmHGPPcRi13xZhjFH/cC','33','33@33','33',0),('333','$2a$10$1wY2wpTq8tgQovkkWh3dD.KC.EMGHGuyE807EqrwaIpkT6vj4clhy','333','333@333','333',0),('444','$2a$10$FG3qVC5u9vzueCYuzPpGve1sU5dfdnuCxZ9vARYbFfdAG2oNeB0ay','444','444@444','444',0),('555','$2a$10$rKxgUGqmpLRFqNS68HSPM.AroFp/u8.F8wzIajAYqhxpwBdtFar1q','555','555@555','555',0),('666','$2a$10$rI58snEZ/NyaLjPcsFMH1.YmnIodAEyJZUi/OyXXnHXsy/ZaBA5nW','666','666@666','666',0),('777','$2a$10$.zFV06ZOJkcTcl0JTJjpBO9RYLxP7Btx7ygW8lzMHh34x/I8Jead2','777','777@777','777',0),('888','$2a$10$X8zpe.LmqlePkvCCZILmBO3.OBXXh501jQgzGFzTjU3qQ2bZs.fqG','888','888@999','888',0),('ab','$2a$10$ghSrfr1YQfuWEZCBEvlmauN9bUPFvykvhWM6ozkXB3eZJ83p1wlJW','ab','ab@ab','ab',0),('admin','$2a$10$/SpTZMoYBIpS1oHORuHxpunM5buACC4eR.F8is9V/y/JjtWMBm9BW','관리자','admin@ssafy.com','010-1234-5667',1),('memberB','$2a$10$AytKFKEWcpkbm8U0.qa/A.tVgkyYEVu3lzzwqFRq9UXnKlUYvRZAu','일반 사용자AA','memberA@ssafy.com','010-1111-1110',0),('memberC','$2a$10$UUl1ZKOzN9wr2/EpFButheVmSfsM.Msbom.HQGdMgohA5AGdWAeMW','일반 사용자C','memberC@ssafy.com','010-1111-1113',0),('ssafy','$2a$10$BjwjHXny6gYE1r8Udwm2V.Fzjq/3CiWYosX8o8BveJ5LZu.ewz/wS','김싸피','kim@ssafy.com','010-1234-5678',0),('ssafy01','$2a$10$4NyOW0/lo5IAeuufT8pLb.xFkY.TYrFDuRQSHNL1Reoa46npJQOMC','이싸피','ssafy01@ssafy.com','010-2312-3242',0),('test','$2a$10$iGFDJRPgznWUqjpcSNfd2OytbkgujMfoEbWJr2rJ9qUedLGh7mnde','test123','test@ssafy.com','010-1111-1234',0),('강남에산다','$2a$10$LH1ZD4grISwnDApfEcpaSuTzpawDWiqAfV8b29qTINoXSGjFhj3lK','rkd','rkd@rkd','342',0),('부동산손님','$2a$10$KkZ7wCeLLQ88T793VptOvui1rHbPEnKkNGoR4cT9u69TLJoc9.dXC','손님','ad@ad','3242',0),('저축왕','$2a$10$ooWvX1XgFcSo0Yfh3QK0EuqphbhDJUu1tE6mGzKak91QrL3x4zpPK','저축왕','abc@abc.com','13123123123',0),('집구하자','$2a$10$2qMYd2cSTYGrIte2gLRm3.SphKtC4tRvk7vtAjR3vdpPoYmGfjMt.','집','w@w','34',0),('집요정','$2a$10$3R5CdGXGlPS7o1d5Vk3Sl.Sq/DMqpRTxV.PaqAz4GETyttVOHSq4S','도비','home@happy.com','010-2342-2341',0);
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-26 10:44:32
